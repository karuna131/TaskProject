module.exports = {
  User: require('./user_model'),
  News: require('./news_model'),
  NewsComments: require('./newsComments_model'),
};
